# 🚀 Como hospedar o Bot do Meu Cachorro no Railway

O Railway é uma alternativa gratuita e simples à Discloud. Siga os passos abaixo:

---

## 1. Crie uma conta no Railway

1. Acesse https://railway.app/
2. Clique em **"Login"** e faça login com sua conta do GitHub (recomendado)
3. Após logar, clique em **"New Project"**

---

## 2. Crie o projeto

1. Clique em **"Deploy from GitHub repo"** (se seu código estiver no GitHub)  
   **OU** clique em **"Deploy from a template"** → escolha **"Empty Project"**
2. Dê um nome ao projeto, exemplo: `bot-do-meu-cachorro`
3. Clique em **"Create Project"**

---

## 3. Adicione o código ao projeto

### Opção A: Via GitHub (recomendado)
1. Suba esta pasta para um repositório no GitHub
2. No Railway, conecte seu GitHub e selecione o repositório
3. O Railway detecta automaticamente que é um projeto Node.js

### Opção B: Upload manual via ZIP
1. Compacte todos os arquivos desta pasta em um `.zip`
2. No Railway, no projeto criado, clique em **"New"** → **"Upload"**
3. Selecione o arquivo `.zip`

---

## 4. Configure as variáveis de ambiente

No painel do Railway, vá na aba **"Variables"** do seu serviço e adicione:

| Nome | Valor |
|------|-------|
| `DISCORD_TOKEN` | Seu token do bot (Discord Developer Portal) |
| `OWNER_ID` | Seu ID de usuário do Discord |
| `BOT_PREFIX` | `!` |

### Como obter o Token:
1. Acesse https://discord.com/developers/applications
2. Selecione seu aplicativo
3. Vá em **Bot** → clique em **"Reset Token"** ou **"Copy Token"**

### Como obter o Owner ID:
1. No Discord, ative **Modo Desenvolvedor** (Configurações de Usuário → Avançado → Modo Desenvolvedor)
2. Clique com o botão direito no seu nome de usuário → **"Copiar ID de Usuário"**

---

## 5. Ative as intents do Discord

No **Discord Developer Portal** → seu bot → **Bot**, ative estes 3 itens:
- ✅ **Presence Intent**
- ✅ **Server Members Intent**
- ✅ **Message Content Intent**

---

## 6. Faça o deploy

1. No Railway, clique em **"Deploy"** (ou ele fará automaticamente ao salvar as variáveis)
2. Aguarde o build completar
3. Nos logs, você deverá ver:
   ```
   [OK] Conectado ao Discord!
   ```

---

## 7. Use o bot no Discord

1. Convide o bot para seu servidor (OAuth2 URL no Developer Portal)
2. No servidor, digite: `!help`
3. Pronto! Seu bot de moderação está online.

---

## 📋 Comandos disponíveis

**Moderação:** `!kick`, `!ban`, `!unban`, `!mute`, `!unmute`, `!warn`, `!warnings`, `!removewarn`, `!clearwarns`, `!clear`, `!slowmode`, `!lock`, `!unlock`

**Utilidade:** `!ping`, `!userinfo`, `!serverinfo`, `!avatar`, `!help`

---

## 🔧 Estrutura do projeto

```
bot-do-meu-cachorro/
├── railway.json          # Config do Railway
├── package.json          # Dependências (discord.js, dotenv)
├── .env.example          # Exemplo de variáveis de ambiente
├── README.md
└── src/
    ├── index.js          # Arquivo principal
    ├── config.js         # Configurações (token, owner, prefix)
    ├── database.js       # Banco de dados JSON (sem dependência nativa)
    ├── handlers/
    │   ├── commandHandler.js
    │   └── eventHandler.js
    ├── events/
    │   ├── ready.js
    │   ├── messageCreate.js (anti-invite, anti-links, anti-caps)
    │   ├── error.js
    │   └── warn.js
    ├── commands/
    │   ├── moderation/   # kick, ban, unban, mute, unmute, warn...
    │   └── utility/      # ping, userinfo, serverinfo, avatar, help
    └── utils/
        ├── embed.js
        ├── isOwner.js
        └── formatMs.js
```

---

## ⚠️ Dicas importantes

- **Não compartilhe seu token** com ninguém
- O Railway oferece um plano gratuito com limites generosos para bots pequenos
- Se o bot desligar, verifique os logs no Railway para diagnosticar
- O banco de dados é salvo em `src/data/database.json` (arquivo local)

---

## 🆘 Se algo der errado

1. Verifique se as variáveis de ambiente estão preenchidas corretamente
2. Verifique se as 3 intents estão ativadas no Discord Developer Portal
3. Confira se o token não expirou
4. Olhe os logs do Railway para ver erros específicos
