# Bot do Meu Cachorro

Bot de moderação para Discord. Pronto para Discloud.

## Como usar

1. Edite `src/config.js` ou `.env` com seu token e owner ID
2. No Discord Developer Portal, ative: Presence Intent, Server Members Intent, Message Content Intent
3. Faça upload do ZIP na Discloud
4. Use `!help` no Discord

## Comandos

Moderação: kick, ban, unban, mute, unmute, warn, warnings, removewarn, clearwarns, clear, slowmode, lock, unlock
Utilidade: ping, userinfo, serverinfo, avatar, help
