const { handleMessage } = require('../handlers/commandHandler');
const db = require('../database');
const config = require('../config');

module.exports = {
  name: 'messageCreate',
  execute: function (client, message) {
    try {
      var antiInvite = db.getAntiInvite(message.guild.id);
      if (antiInvite && /discord\.gg\/|discord\.com\/invite\//i.test(message.content)) {
        if (!message.member.permissions.has('Administrator')) {
          message.delete().catch(function () {});
          message.reply({
            embeds: [{
              color: config.colors.error,
              description: config.emojis.error + ' Convites de servidores não são permitidos aqui.',
            }],
          }).then(function (msg) {
            setTimeout(function () { msg.delete().catch(function () {}); }, 5000);
          }).catch(function () {});
          return;
        }
      }
    } catch (e) {}

    try {
      var antiLinks = db.getAntiLinks(message.guild.id);
      if (antiLinks && /https?:\/\/[^\s]+/i.test(message.content)) {
        if (!message.member.permissions.has('Administrator')) {
          message.delete().catch(function () {});
          message.reply({
            embeds: [{
              color: config.colors.error,
              description: config.emojis.error + ' Links não são permitidos neste servidor.',
            }],
          }).then(function (msg) {
            setTimeout(function () { msg.delete().catch(function () {}); }, 5000);
          }).catch(function () {});
          return;
        }
      }
    } catch (e) {}

    try {
      var antiCaps = db.getAntiCaps(message.guild.id);
      if (antiCaps && message.content.length >= 10) {
        var capsCount = (message.content.match(/[A-Z]/g) || []).length;
        if (capsCount / message.content.length > 0.7) {
          if (!message.member.permissions.has('Administrator')) {
            message.delete().catch(function () {});
            message.reply({
              embeds: [{
                color: config.colors.error,
                description: config.emojis.error + ' Não use excesso de letras maiúsculas.',
              }],
            }).then(function (msg) {
              setTimeout(function () { msg.delete().catch(function () {}); }, 5000);
            }).catch(function () {});
            return;
          }
        }
      }
    } catch (e) {}

    handleMessage(client, message);
  },
};
