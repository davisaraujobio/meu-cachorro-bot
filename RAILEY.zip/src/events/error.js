module.exports = {
  name: 'error',
  execute: function (client, error) {
    console.error('[ERRO] Discord.js:', error);
  },
};
