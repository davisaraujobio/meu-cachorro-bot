module.exports = {
  name: 'warn',
  execute: function (client, warning) {
    console.warn('[AVISO] Discord.js:', warning);
  },
};
