const { ActivityType } = require('discord.js');
const config = require('../config');

module.exports = {
  name: 'ready',
  once: true,
  execute: function (client) {
    console.log('╔═══════════════════════════════════════╗');
    console.log('║  Bot do Meu Cachorro está online!     ║');
    console.log('║  Logado como: ' + client.user.tag + '              ║');
    console.log('║  ID: ' + client.user.id + '                        ║');
    console.log('║  Prefix: ' + config.prefix + '                         ║');
    console.log('║  Owner: ' + config.ownerId + '                     ║');
    console.log('╚════════════════════════════════════════╝');

    try {
      client.user.setPresence({
        activities: [{
          name: config.prefix + 'help | Bot do Meu Cachorro',
          type: ActivityType.Watching,
        }],
        status: 'online',
      });
    } catch (e) {
      console.error('[ERRO] Presença:', e.message);
    }
  },
};
