require('dotenv').config();

const config = {
  token: process.env.DISCORD_TOKEN || 'MTU2MDg3NjI4MDIzMDk3MzUwMw.GBo5vD.lnmhIOVEJl6DzY0JvtfjUhE7zxJeVsA7RiMCM8',
  ownerId: process.env.OWNER_ID || '1551056479862263864',
  prefix: process.env.BOT_PREFIX || '!',

  colors: {
    default: '#2f3136',
    success: '#57F287',
    error: '#ED4245',
    warning: '#FEE75C',
    info: '#5865F2',
  },

  emojis: {
    success: '✅',
    error: '❌',
    warning: '⚠️',
    info: 'ℹ️',
    moderation: '🔨',
    mute: '🔇',
    unmute: '🔊',
    kick: '👢',
    ban: '🔨',
    warn: '⚠️',
    clear: '🧹',
    lock: '🔒',
    unlock: '🔓',
  },
};

module.exports = config;
