const { Client, GatewayIntentBits, Partials, Collection } = require('discord.js');
const config = require('./config');
const { loadCommands } = require('./handlers/commandHandler');
const { loadEvents } = require('./handlers/eventHandler');

if (!config.token || config.token === 'SEU_TOKEN_AQUI') {
  console.error('[ERRO] Token do Discord não configurado!');
  process.exit(1);
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildModeration,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMessageReactions,
  ],
  partials: [Partials.Message, Partials.Channel, Partials.Reaction],
});

client.commands = new Collection();
client.aliases = new Collection();

loadCommands(client);
loadEvents(client);

client.login(config.token)
  .then(function () {
    console.log('[OK] Conectado ao Discord!');
  })
  .catch(function (err) {
    console.error('[ERRO] Falha no login:', err.message);
    process.exit(1);
  });

module.exports = client;
