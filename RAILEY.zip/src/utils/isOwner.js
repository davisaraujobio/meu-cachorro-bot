const config = require('../config');

function isOwner(userId) {
  return userId === config.ownerId;
}

module.exports = { isOwner: isOwner };
