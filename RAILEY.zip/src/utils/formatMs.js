function formatMs(duration) {
  var seconds = Math.floor((duration / 1000) % 60);
  var minutes = Math.floor((duration / (1000 * 60)) % 60);
  var hours = Math.floor((duration / (1000 * 60 * 60)) % 24);
  var days = Math.floor(duration / (1000 * 60 * 60 * 24));

  var parts = [];
  if (days > 0) parts.push(days + ' dia' + (days > 1 ? 's' : ''));
  if (hours > 0) parts.push(hours + ' hora' + (hours > 1 ? 's' : ''));
  if (minutes > 0) parts.push(minutes + ' minuto' + (minutes > 1 ? 's' : ''));
  if (seconds > 0 || parts.length === 0) parts.push(seconds + ' segundo' + (seconds > 1 ? 's' : ''));

  return parts.join(', ');
}

module.exports = { formatMs: formatMs };
