const { EmbedBuilder } = require('discord.js');
const config = require('../config');

function embed(options) {
  options = options || {};
  var embed = new EmbedBuilder()
    .setColor(options.color || config.colors.default)
    .setTimestamp()
    .setFooter({
      text: options.footer || 'Bot do Meu Cachorro - Moderação',
      iconURL: options.iconURL || undefined,
    });

  if (options.title) embed.setTitle(options.title);
  if (options.description) embed.setDescription(options.description);
  if (options.fields) embed.addFields(options.fields);
  if (options.author)
    embed.setAuthor({
      name: options.author.name,
      iconURL: options.author.iconURL || undefined,
      url: options.author.url || undefined,
    });
  if (options.thumbnail) embed.setThumbnail(options.thumbnail);
  if (options.image) embed.setImage(options.image);
  if (options.url) embed.setURL(options.url);

  return embed;
}

module.exports = { embed: embed };
