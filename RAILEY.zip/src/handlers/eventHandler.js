const fs = require('fs');
const path = require('path');

function loadEvents(client) {
  const eventsDir = path.join(__dirname, '..', 'events');
  var count = 0;

  if (!fs.existsSync(eventsDir)) {
    console.error('[ERRO] Pasta de eventos não encontrada:', eventsDir);
    return;
  }

  var files = fs.readdirSync(eventsDir).filter(function (f) { return f.endsWith('.js'); });

  for (var i = 0; i < files.length; i++) {
    var file = files[i];
    var filePath = path.join(eventsDir, file);
    try {
      var event = require(filePath);
      if (!event.name || !event.execute) {
        console.warn('[AVISO] Evento inválido:', file);
        continue;
      }
      if (event.once) {
        client.once(event.name, function () { event.execute(client, arguments); });
      } else {
        client.on(event.name, function () { event.execute(client, arguments); });
      }
      count++;
    } catch (e) {
      console.error('[ERRO] Falha ao carregar evento ' + file + ':', e.message);
    }
  }

  console.log('[OK] ' + count + ' evento(s) carregado(s).');
}

module.exports = { loadEvents: loadEvents };
