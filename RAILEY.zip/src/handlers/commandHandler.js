const fs = require('fs');
const path = require('path');
const config = require('../config');

function loadCommands(client) {
  const commandsDir = path.join(__dirname, '..', 'commands');
  var loaded = 0;

  if (!fs.existsSync(commandsDir)) {
    console.error('[ERRO] Pasta de comandos não encontrada:', commandsDir);
    return;
  }

  var categories = fs.readdirSync(commandsDir);

  for (var i = 0; i < categories.length; i++) {
    var category = categories[i];
    var categoryPath = path.join(commandsDir, category);
    try {
      if (!fs.statSync(categoryPath).isDirectory()) continue;
    } catch (e) { continue; }

    var files = fs.readdirSync(categoryPath).filter(function (f) { return f.endsWith('.js'); });

    for (var j = 0; j < files.length; j++) {
      var file = files[j];
      var filePath = path.join(categoryPath, file);
      try {
        var command = require(filePath);
        if (!command.name || !command.run) {
          console.warn('[AVISO] Comando inválido:', file);
          continue;
        }
        client.commands.set(command.name, command);
        if (command.aliases && Array.isArray(command.aliases)) {
          for (var k = 0; k < command.aliases.length; k++) {
            client.aliases.set(command.aliases[k], command.name);
          }
        }
        loaded++;
      } catch (e) {
        console.error('[ERRO] Falha ao carregar ' + file + ':', e.message);
      }
    }
  }

  console.log('[OK] ' + loaded + ' comando(s) carregado(s).');
}

function handleMessage(client, message) {
  if (message.author.bot) return;
  if (!message.guild) return;

  var prefix = config.prefix;
  if (!message.content.startsWith(prefix)) return;

  var args = message.content.slice(prefix.length).trim().split(/ +/);
  var cmdName = args.shift().toLowerCase();

  var command = client.commands.get(cmdName) ||
    (client.aliases.get(cmdName) ? client.commands.get(client.aliases.get(cmdName)) : null);

  if (!command) return;

  try {
    command.run(client, message, args);
  } catch (error) {
    console.error('[ERRO] Comando ' + command.name + ':', error);
    try {
      message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Ocorreu um erro ao executar este comando.',
        }],
      });
    } catch (e) {}
  }
}

module.exports = { loadCommands: loadCommands, handleMessage: handleMessage };
