const { embed } = require('../../utils/embed');
const config = require('../../config');

module.exports = {
  name: 'unlock',
  description: 'Destrava o canal',
  usage: '!unlock [motivo]',
  category: 'moderação',
  aliases: ['destravar'],

  run: function (client, message, args) {
    if (!message.member.permissions.has('ManageChannels')) {
      return message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Sem permissão.',
        }],
      });
    }

    var reason = args.join(' ') || 'Sem motivo especificado';
    message.channel.permissionOverwrites.edit(message.guild.id, { SendMessages: null }, reason).then(function () {
      message.reply({
        embeds: [{
          color: config.colors.success,
          title: config.emojis.unlock + ' Canal Destravado',
          fields: [
            { name: 'Canal', value: message.channel.toString(), inline: true },
            { name: 'Moderador', value: message.author.tag, inline: true },
            { name: 'Motivo', value: reason },
          ],
        }],
      });
    }).catch(function (err) {
      message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Erro: ' + err.message,
        }],
      });
    });
  },
};
