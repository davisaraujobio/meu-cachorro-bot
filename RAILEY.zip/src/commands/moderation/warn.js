const { embed } = require('../../utils/embed');
const config = require('../../config');
const db = require('../../database');

module.exports = {
  name: 'warn',
  description: 'Adiciona um aviso',
  usage: '!warn <@usuario> [motivo]',
  category: 'moderação',
  aliases: ['avisar'],

  run: function (client, message, args) {
    if (!message.member.permissions.has('KickMembers')) {
      return message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Sem permissão.',
        }],
      });
    }

    var target = message.mentions.members.first();
    if (!target) {
      return message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Mencione um membro.\nUso: ' + config.prefix + 'warn <@usuario> [motivo]',
        }],
      });
    }

    if (target.id === message.author.id) {
      return message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Não pode advertir a si mesmo.',
        }],
      });
    }

    var reason = args.slice(1).join(' ') || 'Sem motivo especificado';

    db.addWarn(message.guild.id, target.id, message.author.id, reason).then(function (warn) {
      db.getWarns(message.guild.id, target.id).then(function (warns) {
        message.reply({
          embeds: [{
            color: config.colors.warning,
            title: config.emojis.warn + ' Advertência',
            fields: [
              { name: 'Usuário', value: target.user.tag + ' (`' + target.id + '`)', inline: true },
              { name: 'Moderador', value: message.author.tag, inline: true },
              { name: 'Total', value: warns.length.toString(), inline: true },
              { name: 'Motivo', value: reason },
              { name: 'ID', value: warn.id },
            ],
          }],
        });
      });
    }).catch(function (err) {
      message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Erro: ' + err.message,
        }],
      });
    });
  },
};
