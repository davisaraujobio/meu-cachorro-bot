const { embed } = require('../../utils/embed');
const config = require('../../config');

module.exports = {
  name: 'slowmode',
  description: 'Modo lento do canal',
  usage: '!slowmode <segundos>',
  category: 'moderação',
  aliases: ['lento', 'slow'],

  run: function (client, message, args) {
    if (!message.member.permissions.has('ManageChannels')) {
      return message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Sem permissão.',
        }],
      });
    }

    var seconds = parseInt(args[0]);
    if (isNaN(seconds) || seconds < 0 || seconds > 21600) {
      return message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Valor entre 0 e 21600.\nUso: ' + config.prefix + 'slowmode <segundos>',
        }],
      });
    }

    message.channel.setRateLimitPerUser(seconds).then(function () {
      if (seconds === 0) {
        return message.reply({
          embeds: [{
            color: config.colors.success,
            description: config.emojis.success + ' Modo lento desativado.',
          }],
        });
      }
      message.reply({
        embeds: [{
          color: config.colors.success,
          description: config.emojis.success + ' Modo lento: ' + seconds + ' segundo(s).',
        }],
      });
    }).catch(function (err) {
      message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Erro: ' + err.message,
        }],
      });
    });
  },
};
