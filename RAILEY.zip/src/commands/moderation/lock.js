const { embed } = require('../../utils/embed');
const config = require('../../config');

module.exports = {
  name: 'lock',
  description: 'Tranca o canal',
  usage: '!lock [motivo]',
  category: 'moderação',
  aliases: ['trancar'],

  run: function (client, message, args) {
    if (!message.member.permissions.has('ManageChannels')) {
      return message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Sem permissão.',
        }],
      });
    }

    var reason = args.join(' ') || 'Sem motivo especificado';
    message.channel.permissionOverwrites.edit(message.guild.id, { SendMessages: false }, reason).then(function () {
      message.reply({
        embeds: [{
          color: config.colors.warning,
          title: config.emojis.lock + ' Canal Trancado',
          fields: [
            { name: 'Canal', value: message.channel.toString(), inline: true },
            { name: 'Moderador', value: message.author.tag, inline: true },
            { name: 'Motivo', value: reason },
          ],
        }],
      });
    }).catch(function (err) {
      message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Erro: ' + err.message,
        }],
      });
    });
  },
};
