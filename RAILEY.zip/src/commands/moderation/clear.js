const { embed } = require('../../utils/embed');
const config = require('../../config');

module.exports = {
  name: 'clear',
  description: 'Apaga mensagens',
  usage: '!clear <quantidade>',
  category: 'moderação',
  aliases: ['limpar', 'purge', 'apagar'],

  run: function (client, message, args) {
    if (!message.member.permissions.has('ManageMessages')) {
      return message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Sem permissão.',
        }],
      });
    }

    var amount = parseInt(args[0]);
    if (!amount || amount < 1 || amount > 100) {
      return message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Número entre 1 e 100.\nUso: ' + config.prefix + 'clear <quantidade>',
        }],
      });
    }

    message.channel.bulkDelete(amount, true).catch(function () {});

    message.channel.send({
      embeds: [{
        color: config.colors.success,
        description: config.emojis.success + ' ' + amount + ' mensagem(ns) apagada(s).',
      }],
    }).then(function (msg) {
      setTimeout(function () { msg.delete().catch(function () {}); }, 3000);
    }).catch(function () {});
  },
};
