const { embed } = require('../../utils/embed');
const config = require('../../config');
const db = require('../../database');

module.exports = {
  name: 'unmute',
  description: 'Remove o silêncio',
  usage: '!unmute <@usuario>',
  category: 'moderação',
  aliases: ['desmutar'],

  run: function (client, message, args) {
    if (!message.member.permissions.has('ModerateMembers')) {
      return message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Sem permissão.',
        }],
      });
    }

    var target = message.mentions.members.first();
    if (!target) {
      return message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Mencione um membro.\nUso: ' + config.prefix + 'unmute <@usuario>',
        }],
      });
    }

    target.timeout(null).then(function () {
      db.removeMute(message.guild.id, target.id);
      message.reply({
        embeds: [{
          color: config.colors.success,
          title: config.emojis.unmute + ' Silêncio Removido',
          fields: [
            { name: 'Usuário', value: target.user.tag + ' (`' + target.id + '`)', inline: true },
            { name: 'Moderador', value: message.author.tag, inline: true },
          ],
        }],
      });
    }).catch(function (err) {
      message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Erro: ' + err.message,
        }],
      });
    });
  },
};
