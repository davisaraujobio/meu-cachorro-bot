const { embed } = require('../../utils/embed');
const config = require('../../config');
const db = require('../../database');

module.exports = {
  name: 'clearwarns',
  description: 'Limpa avisos',
  usage: '!clearwarns <@usuario>',
  category: 'moderação',
  aliases: ['limparavisos'],

  run: function (client, message, args) {
    if (!message.member.permissions.has('KickMembers')) {
      return message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Sem permissão.',
        }],
      });
    }

    var target = message.mentions.members.first();
    if (!target) {
      return message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Mencione um membro.\nUso: ' + config.prefix + 'clearwarns <@usuario>',
        }],
      });
    }

    db.clearWarns(message.guild.id, target.id).then(function () {
      message.reply({
        embeds: [{
          color: config.colors.success,
          title: config.emojis.clear + ' Avisos Limpos',
          fields: [
            { name: 'Usuário', value: target.user.tag + ' (`' + target.id + '`)', inline: true },
            { name: 'Moderador', value: message.author.tag, inline: true },
          ],
        }],
      });
    }).catch(function (err) {
      message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Erro: ' + err.message,
        }],
      });
    });
  },
};
