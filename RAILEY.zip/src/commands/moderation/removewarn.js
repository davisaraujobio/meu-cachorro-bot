const { embed } = require('../../utils/embed');
const config = require('../../config');
const db = require('../../database');

module.exports = {
  name: 'removewarn',
  description: 'Remove um aviso',
  usage: '!removewarn <@usuario> <id>',
  category: 'moderação',
  aliases: ['removeraviso', 'delwarn'],

  run: function (client, message, args) {
    if (!message.member.permissions.has('KickMembers')) {
      return message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Sem permissão.',
        }],
      });
    }

    var target = message.mentions.members.first();
    if (!target) {
      return message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Mencione um membro.\nUso: ' + config.prefix + 'removewarn <@usuario> <id>',
        }],
      });
    }

    var warnId = args[1];
    if (!warnId) {
      return message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Forneça o ID.\nUso: ' + config.prefix + 'removewarn <@usuario> <id>',
        }],
      });
    }

    db.getWarns(message.guild.id, target.id).then(function (warns) {
      var warn = warns.find(function (w) { return w.id === warnId; });
      if (!warn) {
        return message.reply({
          embeds: [{
            color: config.colors.error,
            description: config.emojis.error + ' Aviso não encontrado.',
          }],
        });
      }

      db.removeWarn(message.guild.id, target.id, warnId).then(function () {
        message.reply({
          embeds: [{
            color: config.colors.success,
            title: config.emojis.success + ' Aviso Removido',
            fields: [
              { name: 'Usuário', value: target.user.tag + ' (`' + target.id + '`)', inline: true },
              { name: 'Moderador', value: message.author.tag, inline: true },
              { name: 'Motivo', value: warn.reason },
            ],
          }],
        });
      }).catch(function (err) {
        message.reply({
          embeds: [{
            color: config.colors.error,
            description: config.emojis.error + ' Erro: ' + err.message,
          }],
        });
      });
    }).catch(function (err) {
      message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Erro: ' + err.message,
        }],
      });
    });
  },
};
