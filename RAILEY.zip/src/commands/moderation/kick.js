const { embed } = require('../../utils/embed');
const config = require('../../config');

module.exports = {
  name: 'kick',
  description: 'Expulsa um membro do servidor',
  usage: '!kick <@usuario> [motivo]',
  category: 'moderação',
  aliases: ['expulsar'],

  run: function (client, message, args) {
    if (!message.member.permissions.has('KickMembers')) {
      return message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Você não tem permissão para expulsar membros.',
        }],
      });
    }

    if (!message.guild.members.me.permissions.has('KickMembers')) {
      return message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Eu não tenho permissão para expulsar membros.',
        }],
      });
    }

    var target = message.mentions.members.first();
    if (!target) {
      return message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Mencione um membro.\nUso: ' + config.prefix + 'kick <@usuario> [motivo]',
        }],
      });
    }

    if (target.id === message.author.id) {
      return message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Você não pode expulsar a si mesmo.',
        }],
      });
    }

    if (!target.kickable) {
      return message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Eu não consigo expulsar este membro.',
        }],
      });
    }

    var reason = args.slice(1).join(' ') || 'Sem motivo especificado';

    try {
      target.send({
        embeds: [{
          color: config.colors.warning,
          title: 'Você foi expulso',
          description: '**Servidor:** ' + message.guild.name + '\n**Motivo:** ' + reason + '\n**Moderador:** ' + message.author.tag,
        }],
      }).catch(function () {});
    } catch (e) {}

    target.kick(reason).then(function () {
      message.reply({
        embeds: [{
          color: config.colors.success,
          title: config.emojis.kick + ' Membro Expulso',
          fields: [
            { name: 'Usuário', value: target.user.tag + ' (`' + target.id + '`)', inline: true },
            { name: 'Moderador', value: message.author.tag, inline: true },
            { name: 'Motivo', value: reason },
          ],
        }],
      });
    }).catch(function (err) {
      message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Não foi possível expulsar: ' + err.message,
        }],
      });
    });
  },
};
