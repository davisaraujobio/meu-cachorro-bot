const { embed } = require('../../utils/embed');
const config = require('../../config');

module.exports = {
  name: 'unban',
  description: 'Desbane um usuário do servidor',
  usage: '!unban <id> [motivo]',
  category: 'moderação',

  run: function (client, message, args) {
    if (!message.member.permissions.has('BanMembers')) {
      return message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Você não tem permissão para desbanir.',
        }],
      });
    }

    var userId = args[0];
    if (!userId || !/^\d{17,}$/.test(userId)) {
      return message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' ID inválido.\nUso: ' + config.prefix + 'unban <id> [motivo]',
        }],
      });
    }

    message.guild.bans.fetch().then(function (bans) {
      var ban = bans.find(function (b) { return b.user.id === userId; });
      if (!ban) {
        return message.reply({
          embeds: [{
            color: config.colors.error,
            description: config.emojis.error + ' Este usuário não está banido.',
          }],
        });
      }

      var reason = args.slice(1).join(' ') || 'Sem motivo especificado';
      message.guild.members.unban(userId, reason).then(function () {
        message.reply({
          embeds: [{
            color: config.colors.success,
            title: config.emojis.unlock + ' Usuário Desbanido',
            fields: [
              { name: 'Usuário', value: ban.user.tag + ' (`' + ban.user.id + '`)', inline: true },
              { name: 'Moderador', value: message.author.tag, inline: true },
              { name: 'Motivo', value: reason },
            ],
          }],
        });
      }).catch(function (err) {
        message.reply({
          embeds: [{
            color: config.colors.error,
            description: config.emojis.error + ' Erro: ' + err.message,
          }],
        });
      });
    }).catch(function (err) {
      message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Erro: ' + err.message,
        }],
      });
    });
  },
};
