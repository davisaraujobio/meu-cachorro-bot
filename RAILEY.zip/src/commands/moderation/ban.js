const { embed } = require('../../utils/embed');
const config = require('../../config');

module.exports = {
  name: 'ban',
  description: 'Bane um membro do servidor',
  usage: '!ban <@usuario> [motivo]',
  category: 'moderação',
  aliases: ['banir'],

  run: function (client, message, args) {
    if (!message.member.permissions.has('BanMembers')) {
      return message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Você não tem permissão para banir membros.',
        }],
      });
    }

    if (!message.guild.members.me.permissions.has('BanMembers')) {
      return message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Eu não tenho permissão para banir membros.',
        }],
      });
    }

    var target = message.mentions.members.first();
    if (!target) {
      return message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Mencione um membro.\nUso: ' + config.prefix + 'ban <@usuario> [motivo]',
        }],
      });
    }

    if (target.id === message.author.id) {
      return message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Você não pode banir a si mesmo.',
        }],
      });
    }

    if (!target.bannable) {
      return message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Eu não consigo banir este membro.',
        }],
      });
    }

    var reason = args.slice(1).join(' ') || 'Sem motivo especificado';

    target.ban({ reason: reason }).then(function () {
      message.reply({
        embeds: [{
          color: config.colors.success,
          title: config.emojis.ban + ' Membro Banido',
          fields: [
            { name: 'Usuário', value: target.user.tag + ' (`' + target.id + '`)', inline: true },
            { name: 'Moderador', value: message.author.tag, inline: true },
            { name: 'Motivo', value: reason },
          ],
        }],
      });
    }).catch(function (err) {
      message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Não foi possível banir: ' + err.message,
        }],
      });
    });
  },
};
