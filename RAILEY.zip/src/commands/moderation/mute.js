const { embed } = require('../../utils/embed');
const config = require('../../config');
const db = require('../../database');

function parseTime(timeStr) {
  var match = timeStr.match(/^(\d+)(s|m|h|d)$/);
  if (!match) return null;
  var value = parseInt(match[1]);
  var unit = match[2];
  var multipliers = { s: 1000, m: 60000, h: 3600000, d: 86400000 };
  return value * multipliers[unit];
}

module.exports = {
  name: 'mute',
  description: 'Silencia um membro',
  usage: '!mute <@usuario> <tempo> [motivo]',
  category: 'moderação',
  aliases: ['silenciar'],

  run: function (client, message, args) {
    if (!message.member.permissions.has('ModerateMembers')) {
      return message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Sem permissão para silenciar.',
        }],
      });
    }

    var target = message.mentions.members.first();
    if (!target) {
      return message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Mencione um membro.\nUso: ' + config.prefix + 'mute <@usuario> <tempo> [motivo]',
        }],
      });
    }

    if (target.id === message.author.id) {
      return message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Não pode silenciar a si mesmo.',
        }],
      });
    }

    if (!target.moderatable) {
      return message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Não consigo silenciar este membro.',
        }],
      });
    }

    var time = args[1];
    if (!time) {
      return message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Especifique um tempo (ex: 10m, 1h, 1d).',
        }],
      });
    }

    var duration = parseTime(time);
    if (!duration) {
      return message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Tempo inválido. Use 10m, 1h, 1d.',
        }],
      });
    }

    var reason = args.slice(2).join(' ') || 'Sem motivo especificado';
    var unmuteAt = Date.now() + duration;

    target.timeout(unmuteAt, reason).then(function () {
      db.setMute(message.guild.id, target.id, { unmuteAt: unmuteAt, reason: reason, moderatorId: message.author.id });
      message.reply({
        embeds: [{
          color: config.colors.success,
          title: config.emojis.mute + ' Membro Silenciado',
          fields: [
            { name: 'Usuário', value: target.user.tag + ' (`' + target.id + '`)', inline: true },
            { name: 'Moderador', value: message.author.tag, inline: true },
            { name: 'Tempo', value: time, inline: true },
            { name: 'Motivo', value: reason },
          ],
        }],
      });
    }).catch(function (err) {
      message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Erro: ' + err.message,
        }],
      });
    });
  },
};
