const { embed } = require('../../utils/embed');
const config = require('../../config');
const db = require('../../database');

module.exports = {
  name: 'warnings',
  description: 'Mostra avisos',
  usage: '!warnings <@usuario>',
  category: 'moderação',
  aliases: ['avisos', 'warns'],

  run: function (client, message, args) {
    var target = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
    if (!target) {
      return message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Mencione um membro.\nUso: ' + config.prefix + 'warnings <@usuario>',
        }],
      });
    }

    db.getWarns(message.guild.id, target.id).then(function (warns) {
      var fields = [];
      for (var i = 0; i < warns.length; i++) {
        var w = warns[i];
        fields.push({
          name: 'Aviso #' + (i + 1),
          value: '**Motivo:** ' + w.reason + '\n**Por:** <@' + w.moderatorId + '>\n**Data:** <t:' + Math.floor(w.timestamp / 1000) + ':R>',
          inline: false,
        });
      }

      message.reply({
        embeds: [{
          color: config.colors.info,
          title: config.emojis.warn + ' Avisos de ' + target.user.username,
          description: warns.length === 0 ? 'Sem avisos.' : undefined,
          fields: fields,
          footer: { text: 'Total: ' + warns.length + ' aviso(s)' },
        }],
      });
    }).catch(function (err) {
      message.reply({
        embeds: [{
          color: config.colors.error,
          description: config.emojis.error + ' Erro: ' + err.message,
        }],
      });
    });
  },
};
