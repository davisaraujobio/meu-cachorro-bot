const { EmbedBuilder } = require('discord.js');
const { embed } = require('../../utils/embed');
const config = require('../../config');

module.exports = {
  name: 'serverinfo',
  description: 'Mostra informações do servidor',
  usage: '!serverinfo',
  category: 'utilidade',
  aliases: ['si', 'server'],

  run: function (client, message, args) {
    var guild = message.guild;

    var embedMsg = embed({
      color: config.colors.info,
      title: '🏠 Informações de ' + guild.name,
      thumbnail: guild.iconURL({ dynamic: true, size: 4096 }) || undefined,
      fields: [
        { name: 'Nome', value: guild.name, inline: true },
        { name: 'ID', value: guild.id, inline: true },
        { name: 'Proprietário', value: '<@' + guild.ownerId + '>', inline: true },
        { name: 'Região', value: guild.preferredLocale, inline: true },
        { name: 'Membros', value: guild.memberCount.toString(), inline: true },
        { name: 'Cargos', value: guild.roles.cache.size.toString(), inline: true },
        { name: 'Canais', value: guild.channels.cache.size.toString(), inline: true },
        { name: 'Criado em', value: '<t:' + Math.floor(guild.createdTimestamp / 1000) + ':F>', inline: true },
        { name: 'Nível de verificação', value: guild.verificationLevel, inline: true },
      ],
      footer: { text: 'Solicitado por ' + message.author.tag, iconURL: message.author.displayAvatarURL() },
    });

    message.reply({ embeds: [embedMsg] });
  },
};
