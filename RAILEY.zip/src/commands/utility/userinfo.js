const { EmbedBuilder } = require('discord.js');
const { embed } = require('../../utils/embed');
const config = require('../../config');

module.exports = {
  name: 'userinfo',
  description: 'Mostra informações de um usuário',
  usage: '!userinfo <@usuario>',
  category: 'utilidade',
  aliases: ['ui', 'whois'],

  run: function (client, message, args) {
    var target = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.member;

    var roles = target.roles.cache
      .sort(function (a, b) { return b.position - a.position; })
      .map(function (r) { return r.toString(); })
      .slice(0, -1);

    var embedMsg = embed({
      color: target.displayColor || config.colors.default,
      title: '👤 Informações de ' + target.user.username,
      thumbnail: target.user.displayAvatarURL({ dynamic: true, size: 4096 }),
      fields: [
        { name: 'Nome de usuário', value: target.user.username, inline: true },
        { name: 'Tag', value: target.user.tag, inline: true },
        { name: 'ID', value: target.id, inline: true },
        { name: 'Bot?', value: target.user.bot ? 'Sim' : 'Não', inline: true },
        { name: 'Criado em', value: '<t:' + Math.floor(target.user.createdTimestamp / 1000) + ':F>', inline: true },
        { name: 'Entrou no servidor', value: '<t:' + Math.floor(target.joinedTimestamp / 1000) + ':F>', inline: true },
        { name: 'Cargos', value: roles.length > 0 ? roles.join(', ') : 'Nenhum', inline: false },
      ],
      footer: { text: 'Solicitado por ' + message.author.tag, iconURL: message.author.displayAvatarURL() },
    });

    message.reply({ embeds: [embedMsg] });
  },
};
