const { embed } = require('../../utils/embed');
const config = require('../../config');

module.exports = {
  name: 'ping',
  description: 'Mostra a latência do bot',
  usage: '!ping',
  category: 'utilidade',

  run: function (client, message, args) {
    message.reply('🏓 Calculando ping...').then(function (msg) {
      var embedMsg = embed({
        color: config.colors.info,
        title: '🏓 Pong!',
        fields: [
          { name: 'Latência da API', value: Math.round(client.ws.ping) + 'ms', inline: true },
          { name: 'Latência da mensagem', value: Math.round(msg.createdAt - message.createdAt) + 'ms', inline: true },
        ],
      });

      msg.edit({ content: '', embeds: [embedMsg] });
    }).catch(function () {});
  },
};
