const { embed } = require('../../utils/embed');
const config = require('../../config');

module.exports = {
  name: 'avatar',
  description: 'Mostra o avatar de um usuário',
  usage: '!avatar <@usuario>',
  category: 'utilidade',
  aliases: ['av', 'pfp'],

  run: function (client, message, args) {
    var target = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.member;

    var embedMsg = embed({
      color: target.displayColor || config.colors.default,
      title: '🖼️ Avatar de ' + target.user.username,
      image: target.user.displayAvatarURL({ dynamic: true, size: 4096 }),
      footer: { text: 'Solicitado por ' + message.author.tag, iconURL: message.author.displayAvatarURL() },
    });

    message.reply({ embeds: [embedMsg] });
  },
};
