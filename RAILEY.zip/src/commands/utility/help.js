const { EmbedBuilder } = require('discord.js');
const { embed } = require('../../utils/embed');
const config = require('../../config');
const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'help',
  description: 'Mostra a lista de comandos',
  usage: '!help [comando]',
  category: 'utilidade',
  aliases: ['ajuda', 'comandos'],

  run: function (client, message, args) {
    var commandsDir = path.join(__dirname, '..');
    var categories = {};

    function loadCommands(dir) {
      var files = fs.readdirSync(dir);
      for (var i = 0; i < files.length; i++) {
        var file = files[i];
        var filePath = path.join(dir, file);
        try {
          if (fs.statSync(filePath).isDirectory()) {
            loadCommands(filePath);
          } else if (file.endsWith('.js')) {
            var cmd = require(filePath);
            var category = cmd.category || 'outros';
            if (!categories[category]) categories[category] = [];
            categories[category].push(cmd);
          }
        } catch (e) {}
      }
    }

    loadCommands(commandsDir);

    if (args[0]) {
      var cmdName = args[0].toLowerCase();
      var foundCmd = null;
      for (var cat in categories) {
        foundCmd = categories[cat].find(function (c) {
          return c.name === cmdName || (c.aliases && c.aliases.indexOf(cmdName) !== -1);
        });
        if (foundCmd) break;
      }

      if (!foundCmd) {
        return message.reply({
          embeds: [{
            color: config.colors.error,
            description: config.emojis.error + ' Comando não encontrado.',
          }],
        });
      }

      return message.reply({
        embeds: [{
          color: config.colors.info,
          title: '❓ Ajuda: ' + foundCmd.name,
          fields: [
            { name: 'Descrição', value: foundCmd.description, inline: false },
            { name: 'Uso', value: foundCmd.usage, inline: false },
            (foundCmd.aliases && foundCmd.aliases.length > 0) ? { name: 'Apelidos', value: foundCmd.aliases.join(', '), inline: false } : null,
            { name: 'Categoria', value: foundCmd.category, inline: false },
          ].filter(Boolean),
        }],
      });
    }

    var embedMsg = new EmbedBuilder()
      .setColor(config.colors.info)
      .setTitle('📋 Comandos do Bot do Meu Cachorro')
      .setDescription('Prefixo: `' + config.prefix + '`\nUse `' + config.prefix + 'help <comando>` para detalhes.')
      .setTimestamp()
      .setFooter({ text: 'Bot do Meu Cachorro - Moderação' });

    for (var cat in categories) {
      var cmds = categories[cat];
      embedMsg.addFields({
        name: cat.charAt(0).toUpperCase() + cat.slice(1) + ' (' + cmds.length + ')',
        value: cmds.map(function (c) { return '`' + config.prefix + c.name + '`'; }).join(', '),
        inline: false,
      });
    }

    message.reply({ embeds: [embedMsg] });
  },
};
