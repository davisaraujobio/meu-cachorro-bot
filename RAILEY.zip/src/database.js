const fs = require('fs');
const path = require('path');

const dataDir = path.join(__dirname, 'data');
const dbPath = path.join(dataDir, 'database.json');

let database = {};

try {
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
  if (fs.existsSync(dbPath)) {
    const raw = fs.readFileSync(dbPath, 'utf8');
    database = JSON.parse(raw);
  }
} catch (e) {
  console.error('[DB] Erro ao iniciar:', e.message);
  database = {};
}

function save() {
  try {
    fs.writeFileSync(dbPath, JSON.stringify(database, null, 2));
  } catch (e) {
    console.error('[DB] Erro ao salvar:', e.message);
  }
}

function getKey(key) {
  return database[key];
}

function setKey(key, value) {
  database[key] = value;
  save();
}

function deleteKey(key) {
  delete database[key];
  save();
}

module.exports = {
  addWarn: async function (guildId, userId, moderatorId, reason) {
    const key = 'warns_' + guildId + '_' + userId;
    const warns = getKey(key) || [];
    const warn = {
      id: Date.now().toString(),
      moderatorId: moderatorId,
      reason: reason,
      timestamp: Date.now(),
    };
    warns.push(warn);
    setKey(key, warns);
    return warn;
  },

  getWarns: async function (guildId, userId) {
    return getKey('warns_' + guildId + '_' + userId) || [];
  },

  removeWarn: async function (guildId, userId, warnId) {
    const warns = await this.getWarns(guildId, userId);
    const filtered = warns.filter(function (w) { return w.id !== warnId; });
    setKey('warns_' + guildId + '_' + userId, filtered);
    return filtered;
  },

  clearWarns: async function (guildId, userId) {
    deleteKey('warns_' + guildId + '_' + userId);
  },

  setMute: async function (guildId, userId, data) {
    setKey('mute_' + guildId + '_' + userId, data);
  },

  getMute: async function (guildId, userId) {
    return getKey('mute_' + guildId + '_' + userId);
  },

  removeMute: async function (guildId, userId) {
    deleteKey('mute_' + guildId + '_' + userId);
  },

  setConfig: async function (guildId, key, value) {
    setKey('config_' + guildId + '_' + key, value);
  },

  getConfig: async function (guildId, key) {
    return getKey('config_' + guildId + '_' + key);
  },

  setAntiInvite: async function (guildId, enabled) {
    setKey('config_' + guildId + '_antiInvite', enabled);
  },

  getAntiInvite: async function (guildId) {
    return getKey('config_' + guildId + '_antiInvite');
  },

  setAntiLinks: async function (guildId, enabled) {
    setKey('config_' + guildId + '_antiLinks', enabled);
  },

  getAntiLinks: async function (guildId) {
    return getKey('config_' + guildId + '_antiLinks');
  },

  setAntiCaps: async function (guildId, enabled) {
    setKey('config_' + guildId + '_antiCaps', enabled);
  },

  getAntiCaps: async function (guildId) {
    return getKey('config_' + guildId + '_antiCaps');
  },
};
